import sys
from cx_Freeze import setup, Executable

# Dependencies are automatically detected, but it might need fine tuning.
excludes_options = ['matplotlib', 'numpy', 'scipy']
DATA_FILES = ["Rescon_Files", 'User_Guide_ResCon.pdf', 'importmodul.py', 'Rescon_Files//Template_html5_ChartNewjs.txt']

build_exe_options = {"packages": ["os"], 
					"excludes":excludes_options,
					"includes": ['xmltramp2']
					}


# GUI applications require a different base on Windows (the default is for a
# console application).
base = None
if sys.platform == "win32":
    base = "Win32GUI"

setup(  name = "ResCon (beta25)",
        version = "1.25",
        description = "ResCon 1.25 beta",
		data_files=DATA_FILES,
        options = {"build_exe": build_exe_options},
        executables = [Executable("ResCon_Ver25.py",
						base=base, 
						icon= 'Rescon_Files//ResCon_windows_logo.ico'
						)])
		